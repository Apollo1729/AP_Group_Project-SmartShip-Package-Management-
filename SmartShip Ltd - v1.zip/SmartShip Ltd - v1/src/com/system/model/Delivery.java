package com.system.model;

public class Delivery {
	
	//For the deliveries we need to know the following
	
	/* 
	 * 1. The types of packages that are to be delivered
	 * 2. The number of packages that will be delivered
	 * 3.
	 * */

}
