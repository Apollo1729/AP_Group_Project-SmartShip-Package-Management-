package com.system.model;
import javax.swing.*;
import java.io.Serializable;

public class Customer extends User implements Serializable{

		private static final long serialVersionUID = 1L;
		private int cusId;
		private String paymentMethod;
		
		
		//default constructor
		public Customer() {
			super();
			this.cusId = 0;
			this.paymentMethod = "";
		}
		
		//primary constructor
		public Customer(String firstName, String lastName, Date dob, int age, String nationalId, Address address, String telNum, String username, String password, String email, int cusId, String paymentMethods) {
			super(firstName,lastName, dob, age, nationalId, address, telNum,  username,  password,  email);
			this.cusId = cusId;
			this.paymentMethod = paymentMethods;
		}
		
		//Copy constructor
		public Customer(Customer cus) {
			super(cus);
			this.cusId = cus.cusId;
			this.paymentMethod = cus.paymentMethod;
		}
		
		
		//setters and getters
		public int getCusId() {
			return this.cusId;
		}

		public void setCusId(int cusId) {
			this.cusId = cusId;
		}

		public String getPaymentMethod() {
			return this.paymentMethod;
		}

		public void setPaymentMethod(String paymentMethod) {
			this.paymentMethod = paymentMethod;
		}
		
		/* Customers can create accounts
		 * Login 
		 * Create Shipments
		 * */
		


		/*@Override
		public String toString() {
			return "Customer ID: " + cusId +
					"\nFirst Name: " + firstName + 
					"\nLast Name: " + lastName + 
					"\nDob: " + dob + 
					"\nAge:" + age + 
					"\nNational Id: " + nationalId + 
					"\nAddress: " + address + 
					"\nTel Number: " + telNum + "\n";
		}*/
		
		@Override
		public String toString() {
			return "Customer ID: " + cusId + super.toString() + "\n";
		}
		
}
