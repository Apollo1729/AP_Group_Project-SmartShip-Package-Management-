package com.system.model;

import java.io.Serializable;

public class Clerk extends User implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private int clerkId;
	
	//default constructor
	public Clerk() {
		super();
		this.clerkId = 0;
	}
			
	//primary constructor
	public Clerk(String firstName, String lastName, Date dob, int age, String nationalId, Address address, String telNum, String username, String password, String email, int clerkId) {
		super(firstName,lastName, dob, age, nationalId, address, telNum, username, password, email);
		this.clerkId = clerkId;
	}
			
	//Copy constructor
	public Clerk(Clerk clk) {
		super(clk);
		this.clerkId = clk.clerkId;
	}
	
	//setters and getters
			
	public int getClerkId() {
		return this.clerkId;
	}

	public void setClerkId(int clerkId) {
		this.clerkId = clerkId;
	}

	@Override
	public String toString() {
		return "Clerk ID: " + clerkId + super.toString() + "\n";
	}
	
}//end of class 
