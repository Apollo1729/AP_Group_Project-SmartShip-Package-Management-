package com.system.controller;
import com.system.view.*;

public class Driver {

	public static void main(String[] args) {

			new Application();
	}

}
